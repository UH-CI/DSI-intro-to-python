let _ = {};

(() => {
	_.http_request = (url, method, headers, body) => {
		return new Promise((resolve, reject) => {
			let request = new XMLHttpRequest();
			
			request.addEventListener("load", (event) => {
				resolve(request.responseText);
			});
			request.addEventListener("error", (event) => {
				reject(event);
			});
			request.addEventListener("abort", (event) => {
				reject(event);
			});
			
			request.open(method, url, true);
			if (!headers || headers[0] !== null) {
				request.setRequestHeader("Cache-Control", "no-cache");
				request.setRequestHeader("X-Requested-With", "XMLHttpRequest");
			}
			
			if (headers) {
				for (let i = 0; i < headers.length; i++) {
					if (headers[i]) {
						request.setRequestHeader(headers[i][0], headers[i][1]);
					}
				}
			}
			
			request.send(body);
		});
	};
	
	_.get = (url, headers) => {
		return _.http_request(url, "GET", headers, null);
	}
	
	_.post = (url, headers, body) => {
		return _.http_request(url, "POST", headers, body);
	}
	
	_.getJSON = (url) => {
		return _.get(url).then((response, request) => {
			return JSON.parse(response);
		});
	};
})();

export default _;