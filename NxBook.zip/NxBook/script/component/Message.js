class Message extends HTMLElement {
	// FUTURE: Consider removing this component
	constructor() {
		// Always call super first in constructor
		super();
		
		this._titleElement = undefined;
		this._textElement = undefined;
		
		// Create a shadow root
		let shadow = this.attachShadow({mode: "open"});
		this._shadowElement = shadow;

		let style = document.createElement("style");
		style.textContent = `
:host {
	display: block;
	background: #C1E8FF;
	margin: 10px 0;
	padding: 20px;
	border-radius: 2px;
	border-left: 5px solid #0BA5FF;
	font-family: "Roboto", Helvetica, "Times New Roman", sans-serif;
	font-size: 16px;
	font-weight: 300;
}

:host([italicize]) div {
	font-style: italic;
}

h1 {
	position: relative;
	margin: 0;
	padding: 0;
	font-size: 18px;
	font-weight: normal;
}

h1 ~ div {
	margin-top: 10px;
}

:host([count]) h1::after {
	content: attr(current) " of " attr(max);
	position: absolute;
	right: 0;
	color: rgba(0, 0, 0, 0.7);
}

:host([type=warning]) {
	background: #FFF9C1;
	border-left-color: #FFD30B;
}

:host([type=success]) {
	background: #C0FBD2;
	border-left-color: #0DE03A;
}

:host([type=error]) {
	background: #FFC1C1;
	border-left-color: #FF160B;
}

code,
pre {
	padding: 2px 5px;
	font-family: "Roboto Mono", monospace;
	border-radius: 2px;
	background: #EEE;
}

pre code {
	background: #FDD835;
}
`;

		// Attach the created elements to the shadow dom
		shadow.appendChild(style);
		
		let observer = new MutationObserver((records, observer) => this.observed(records, observer));
		let observationConfig = {attributeFilter: ["title", "text", "current", "max"], attributes: true};
		observer.observe(this, observationConfig);
		
		this.update();
	}

	connectedCallback() {
		this.update();
	}
	
	update() {
		let title = this.getAttribute("title");
		let text = this.getAttribute("text");
		
		if (title) {
			if (!this._titleElement) {
				this._titleElement = document.createElement("h1");
			
				if (this.hasAttribute("current")) {
					this._titleElement.setAttribute("current", this.getAttribute("current"));
				}
				if (this.hasAttribute("max")) {
					this._titleElement.setAttribute("max", this.getAttribute("max"));
				}
				
				this._shadowElement.insertBefore(this._titleElement, this._shadowElement.firstChild);
			}
			
			this._titleElement.innerHTML = title;
		} else {
			if (this._titleElement) {
				this._shadowElement.removeChild(this._titleElement);
				this._titleElement = undefined;
			}
		}
		
		if (text) {
			if (!this._textElement) {
				this._textElement = document.createElement("div");
				this._shadowElement.appendChild(this._textElement);
			}
			
			this._textElement.innerHTML = text;
		} else {
			if (this._textElement) {
				this._shadowElement.removeChild(this._textElement);
				this._textElement = undefined;
			}
		}
	}
	
	observed(records, observer) {
		let needsUpdate = false;
		for (let i = 0; i < records.length; i++) {
			let record = records[i];
			
			if (record.type == "attributes" && (record.attributeName == "current" || record.attributeName == "max")) {
				if (this._titleElement) {
					if (this.hasAttribute(record.attributeName)) {
						this._titleElement.setAttribute(record.attributeName, this.getAttribute(record.attributeName));
					} else {
						this._titleElement.removeAttribute(record.attributeName);
					}
				}
			} else {
				needsUpdate = true;
			}
		}
		
		if (needsUpdate) {
			this.update();
		}
	}
}

customElements.define("nxbook-message", Message);
export default Message;
