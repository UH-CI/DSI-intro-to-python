class BaseComponent extends HTMLElement {
	
}

export default BaseComponent;
