import Message from "./Message.js";

class AnswerChoices extends HTMLElement {
	get type() {
		return this._type;
	}

	set type(value) {
		if (typeof value != "string") {
			throw new TypeError("The type property of AnswerChoices must be a string!");
		}
		value = value.toLowerCase();
		if (value != "radio" && value != "checkbox") {
			throw new TypeError("The type property of AnswerChoices may only be one of radio or checkbox!");
		}

		this._type = value;
		this.setAttribute("type", value);
	}

	get choices() {
		return this._choices;
	}

	set choices(value) {
		this._choices = value;
		this.update();
	}

	get value() {
		let formData = new FormData(this._formElement);
		
		let values = formData.getAll("input");
		
		// Convert string numbers to numbers
		for (let i = 0; i < values.length; i++) {
			values[i] = isNaN(parseInt(values[i], 10)) ? values[i] : parseInt(values[i], 10);
		}
		// Change to a single value for single choice questions
		if (this._type == "radio") {
			values = values[0];
		}
		
		return values;
	}

	constructor() {
		// Always call super first in constructor
		super();

		this._choices = [];
		this._type = "radio";
		this._inputElements = [];

		// Create a shadow root
		let shadow = this.attachShadow({mode: "open"});
		this._shadowElement = shadow;

		/*
		<div class="choices columns">
			<div class="column">
				<label class="item"><input type="radio" name="q1" value="1"><div class="answer">byte</div></label>
				<label class="item"><input type="radio" name="q1" value="2"><div class="answer">int</div></label>
				<label class="item"><input type="radio" name="q1" value="3"><div class="answer">boolean</div></label>
			</div>
			<div class="column">
				<label class="item"><input type="radio" name="q1" value="4"><div class="answer">String</div></label>
				<label class="item"><input type="radio" name="q1" value="5"><div class="answer">float</div></label>
				<label class="item"><input disabled type="radio" name="q1" value="6"><div class="answer">disabled input</div></label>
			</div>
		</div>

		<div class="choices">
			<label class="item"><input type="radio" value="1"><div class="answer"><code>FIFO</code> First in first out</div></label>
			<label class="item"><input type="checkbox" value="2"><div class="answer"><code>FILO</code> First in last out</div></label>
			<label class="item"><input type="checkbox" value="3"><div class="answer"><code>LIFO</code> Last in first out</div></label>
			<label class="item"><input type="checkbox" value="4"><div class="answer"><code>LILO</code> Last in last out</div></label>
		</div>
		*/

		// Create elements
		let form = document.createElement("form");
		this._formElement = form;
		form.className = "wrapper";

		let style = document.createElement("style");
		style.textContent = `
:host {
	display: block;
	font-weight: 300;
	/* Prevent selections */
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

:host > .wrapper {
	display: contents;
}

.item {
	display: block;
	margin: 10px 0;
	padding: 15px 15px 15px 47px;
	border: 2px solid rgba(0, 0, 0, 0);
	border-radius: 2px;
	background: #EEE;
}

.item.success {
	border: 2px solid #0DE03A;
}

.item.error {
	border: 2px solid #FF160B;
}

code,
pre {
	margin: 0;
	padding: 2px 5px;
	font-family: "Roboto Mono", monospace;
	border-radius: 2px;
	background: #FFF;
}

code {
	/* Correct appearance in italicized text */
	margin: 0 -2px 0 2px;
	padding: 2px 6px 2px 4px;
}

pre code {
	background: #FDD835;
}

input {
	font-family: "Roboto", Helvetica, "Times New Roman", sans-serif;
	border: 1px solid #DADCE0;
	box-sizing: border-box;
	margin: 0;
	border-radius: 4px;
	outline: none;
	background: #FFF;
	font-size: 14px;
	transition: border-color 50ms;
	padding: 10px;
}

input[type=checkbox],
input[type=radio] {
	position: absolute;
	opacity: 0;
}

input[type=checkbox] + .answer,
input[type=radio] + .answer {
	position: relative;
	padding: 0;
}

input[type=checkbox] + .answer::before,
input[type=radio] + .answer::before {
	content: '';
	position: absolute;
	display: inline-block;
	top: 50%;
	left: -32px;
	width: 20px;
	height: 20px;
	margin-right: 10px;
	border: 1px solid #DADCE0;
	background: #FFF;
	vertical-align: middle;
	cursor: pointer;
	transform: translateY(-50%)
}

input[type=radio] + .answer::before {
	border-radius: 100%;
}

input[type=checkbox]:hover + .answer::before,
input[type=radio]:hover + .answer::before {
	background: rgba(0, 0, 0, 0.08);
}

input[type=checkbox]:hover:not(:disabled) + .answer::before,
input[type=radio]:hover:not(:disabled) + .answer::before {
	border: 1px solid rgba(0, 0, 0, 0.08);
}

input[type=checkbox]:focus + .answer::before,
input[type=radio]:focus + .answer::before,
input[type=checkbox]:active + .answer::before,
input[type=radio]:active + .answer::before {
/*	box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.12);*/
	box-shadow: 0 0 0 3px #90C9F9;
}

input[type=checkbox]:checked + .answer::before,
input[type=radio]:checked + .answer::before {
	border: 1px solid rgba(0, 0, 0, 0.08);
	background: #2196F3;
}

input[type=checkbox]:disabled + .answer,
input[type=radio]:disabled + .answer {
	color: #B8B8B8;
	cursor: default;
}

input[type=checkbox]:disabled + .answer::before,
input[type=radio]:disabled + .answer::before {
	box-shadow: none;
	background: #DDD;
	cursor: default;
}

input[type=checkbox]:checked + .answer::after {
	content: '';
	display: block;
	position: absolute;
	left: -24px;
	top: 50%;
	width: 4px;
	height: 8px;
	border: solid #FFF;
	border-width: 0 2px 2px 0;
	cursor: pointer;
	transform: translateY(calc(-50% - 1px)) rotate(45deg);
}

input[type=radio]:checked + .answer::after {
	content: '';
	display: block;
	position: absolute;
	left: -25px;
	top: 50%;
	width: 8px;
	height: 8px;
	border-radius: 100%;
	background:#FFF;
	transform: translateY(-50%)
}
`;

		// Attach the created elements to the shadow dom
		shadow.appendChild(style);
		shadow.appendChild(form);

		let observer = new MutationObserver((records, observer) => this.observed(records, observer));
		let observationConfig = {attributeFilter: ["type"], attributes: true};
		observer.observe(this, observationConfig);

		this.update();
	}

	connectedCallback() {
		this.update();
	}

	update() {
		while (this._formElement.lastChild) {
			this._formElement.removeChild(this._formElement.lastChild);
		}

		this._inputElements = [];
		
		for (let i = 0; i < this._choices.length; i++) {
			let choice = this._choices[i];
			let item = document.createElement("label");
			item.className = "item";
			let input = document.createElement("input");
			input.type = this._type;
			input.setAttribute("name", "input");
			input.setAttribute("value", i);
			let answer = document.createElement("div");
			answer.className = "answer";
			answer.innerHTML = choice;

			item.appendChild(input);
			item.appendChild(answer);
			this._formElement.appendChild(item);
			this._inputElements.push(item);
		}
	}

	observed(records, observer) {
		this._type = this.getAttribute("type");
		this.update();
	}

	reset() {
		this._formElement.reset();
		this.decorate([]);
	}
	
	hasDefaultValues() {
		// FUTURE: So that the multi-question navigator can tell whether or not the question was "answered"
	}
	
	decorate(decorators) {
		for (let i = 0; i < Math.max(decorators.length, this._choices.length); i++) {
			let item = this._inputElements[i];
			let decorator = decorators[i];
			
			// Reset class and feedback
			item.className = "item";
			if (item.children.length > 2) {
				item.removeChild(item.children[2]);
			}
			
			if (decorator) {
				// Add class
				item.className += ` ${decorator.type}`;
				
				// Add feedback
				if (decorator.text) {
					let feedbackElement = new Message();
					feedbackElement.setAttribute("type", decorator.type)
					feedbackElement.setAttribute("text", decorator.text);
					feedbackElement.setAttribute("italicize", "");
					
					item.appendChild(feedbackElement);
				}
			}
		}
	}
}

customElements.define("nxbook-choices", AnswerChoices);
export default AnswerChoices;
