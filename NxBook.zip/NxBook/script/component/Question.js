import _ from "../lib.js";
import AnswerChoices from "./AnswerChoices.js";
import Message from "./Message.js";

class Question extends HTMLElement {
	get value() {
		let questionID = this.getAttribute("question-id");
		let answer = this._choicesElement.value;
		
		// TODO: Make context-aware: multi-question quiz, or single question?
		return {id: questionID, value: answer};
	}
	
	set token(value) {
		this._oauthToken = value;
	}
	
	constructor() {
		// Always call super first in constructor
		super();

		this._question = undefined;
		this._lastHint = Infinity;
		this._oauthToken = undefined;
		this._userID = undefined;
		
		// Create a shadow root
		let shadow = this.attachShadow({mode: "open"});

		/*
		<h1>Which of the following is characteristic of a <code>stack</code> ADT?</h1>
		<div class="detail">Choose all that apply</div>
		<nxbook-message type="error" text="Incorrect"></nxbook-message>
		<div class="choices">
			<label class="item"><input disabled type="checkbox" value="fifo"><div class="answer"><code>FIFO</code> First in first out</div></label>
			<label class="item"><input type="checkbox" value="filo"><div class="answer"><code>FILO</code> First in last out</div></label>
			<label class="item"><input type="checkbox" value="lifo"><div class="answer"><code>LIFO</code> Last in first out</div></label>
			<label class="item"><input type="checkbox" value="lilo"><div class="answer"><code>LILO</code> Last in last out</div></label>
		</div>
		<nxbook-message type="warning" title="Hint" text="Think of a stack as a pile of physical objects." count current="1" max="5"></nxbook-message>
		<div class="footer">
			<button type="button">hint</button>
			<button type="reset" style="margin-left: auto;">clear</button>
			<button type="submit">submit</button>
		</div>
		*/
		
		// Create elements
		let questionElement = document.createElement("h1");
		this._questionElement = questionElement;
		let detailElement = document.createElement("div");
		this._detailElement = detailElement;
		detailElement.className = "detail";
		detailElement.innerText = "Loading...";
		let feedbackElement = new Message();
		this._feedbackElement = feedbackElement;
		feedbackElement.style.display = "none";
		let choicesElement = new AnswerChoices();
		this._choicesElement = choicesElement;
		let hintElement = new Message();
		this._hintElement = hintElement;
		hintElement.setAttribute("title", "Hint");
		hintElement.setAttribute("type", "warning");
		hintElement.setAttribute("count", "");
		hintElement.style.display = "none";
		let footerElement = document.createElement("div");
		footerElement.className = "footer";
		let hintButton = document.createElement("button");
		this._hintButtonElement = hintButton;
		hintButton.innerText = "Show Hint";
		hintButton.setAttribute("text", "Hint");
		hintButton.style.display = "none";
		hintButton.addEventListener("click", () => {
			this.showNextHint();
		});
		let clearButton = document.createElement("button");
		clearButton.className = "reset";
		clearButton.innerText = "Clear";
		clearButton.setAttribute("text", "Clear");
		clearButton.style.marginLeft = "auto";
		clearButton.addEventListener("click", () => {
			this.reset();
		});
		let submitButton = document.createElement("button");
		submitButton.className = "submit";
		submitButton.innerText = "Submit";
		submitButton.setAttribute("text", "Submit");
		submitButton.addEventListener("click", () => {
			console.log(this.value);
			this.resetHints();
			
			let answers = this._question.answers;
			let correctAnswer = this._question.correct_answer;
			let userAnswer = choicesElement.value;
			console.log('userAnswer', userAnswer);
			let decorators = [];
			// If allCorrect, then all selected options are correct
			// If allWrong, then all selected options are wrong
			// If !allCorrect && !allWrong, then question is partially correct
			// if allCorrect && allWrong, then no options were selected
			let allCorrect = true;
			let allWrong = true;
			
			if (this._question.type == "checkbox") {
				for (let i = 0; i < answers.length; i++) {
					let decorator = {};
					
					if (userAnswer.indexOf(i) > -1) {
						decorator.type = correctAnswer.indexOf(i) > -1 ? "success" : "error";
						
						if (this._question.explanations[i]) {
							decorator.text = this._question.explanations[i];
						}
						
						if (correctAnswer.indexOf(i) == -1) {
							allCorrect = false;
						} else {
							allWrong = false;
						}
					} else {
						if (correctAnswer.indexOf(i) > -1) {
							allCorrect = false;
						}
					}
					
					decorators.push(decorator);
				}
			} else if (this._question.type == "radio") {
				let decorator = {};
				
				if (userAnswer !== undefined) {
					decorator.type = userAnswer == correctAnswer ? "success" : "error";
					if (this._question.explanations[userAnswer]) {
						decorator.text = this._question.explanations[userAnswer];
					}
					
					if (userAnswer != correctAnswer) {
						allCorrect = false;
					} else {
						allWrong = false;
					}
					
					for (let i = 0; i < userAnswer; i++) {
						decorators.push(null);
					}
					decorators.push(decorator);
				}
			}
			
			// If question is submitted with no options selected, show incorrect message
			feedbackElement.style = "";
			if (allWrong) {
				feedbackElement.setAttribute("type", "error");
				feedbackElement.setAttribute("title", "Incorrect");
				feedbackElement.removeAttribute("text");
			} else if (allCorrect) {
				feedbackElement.setAttribute("type", "success");
				feedbackElement.setAttribute("title", "Correct");
				feedbackElement.removeAttribute("text");
			} else {
				feedbackElement.setAttribute("type", "warning");
				feedbackElement.setAttribute("title", "Partially Correct");
				feedbackElement.setAttribute("text", "Some selected answers may be incorrect, or there may be more correct answers that are not selected.");
			}
			
			if (!this._oauthToken) {
				feedbackElement.setAttribute("type", "error");
				feedbackElement.setAttribute("title", "Authentication Error");
				feedbackElement.setAttribute("text", "Failed to authenticate! Check your login credentials at the top!");
				
				return;
			}
			
			_.post("https://nxbook.appspot.com/nxbook/api/v1.0/answers", [
				["Content-Type", "application/json"],
				["Authorization", `OAuth ${this._oauthToken}`]
			], JSON.stringify({user_id: this._userID, module: this._question.module, question_id: this.getAttribute("question-id"), answer: userAnswer, correct: allWrong && "incorrect" || (allCorrect && "correct" || "partial"), timestamp: Date.now()}));
			
			console.log(decorators);
			choicesElement.decorate(decorators);
		});

		let style = document.createElement("style");
		style.textContent = `
:host {
	display: block;
	margin: 10px 0;
	padding: 20px;
	border: 1px solid #DADCE0;
	border-radius: 8px;
	font-family: "Roboto", Helvetica, "Times New Roman", sans-serif;
	font-size: 16px;
	font-weight: 300;
	box-shadow: 0 2px 6px 0 rgba(60, 64, 67, .15);
	box-sizing: border-box;
}

h1 {
	margin: 0 0 10px 0;
	padding: 0;
	font-size: 22px;
	font-weight: normal;
}

.detail {
	margin-bottom: 15px;
}

.footer {
	display: flex;
}

code,
pre {
	padding: 2px 5px;
	font-family: "Roboto Mono", monospace;
	border-radius: 2px;
	background: #EEE;
}

pre code {
	background: #FDD835;
}

button {
	min-width: 64px;
	height: 36px;
	margin: 0 5px;
	padding: 0 16px;
	border: 1px solid #DADCE0;
	border-radius: 4px;
	outline: none;
	background: #FFF;
	font-family: "Roboto", Helvetica, "Times New Roman", sans-serif;
	font-size: 0.875em;
	font-weight: bold;
	line-height: 36px;
	text-transform: uppercase;
	box-sizing: border-box;
	transition: border-color 100ms, background 100ms, box-shadow 200ms, opacity 100ms;
	cursor: pointer;
}

button:first-child {
	margin-left: 0;
}

button:last-child {
	margin-right: 0;
}

button:hover {
	box-shadow: 0 2px 4px -1px rgba(0,0,0,.2), 0 4px 5px 0 rgba(0,0,0,.08), 0 1px 10px 0 rgba(0,0,0,.12);
}

button:focus {
	border-color: #2196F3;
}

button:active {
	opacity: 0.78;
}

button.submit {
	border: 1px solid #2196F3;
	background: #2196F3;
	color: #FFF;
}

button.reset {
	border: 1px solid #F44336;
	background: #F44336;
	color: #FFF;
}
`;

		// Attach the created elements to the shadow dom
		shadow.appendChild(style);
		shadow.appendChild(questionElement);
		shadow.appendChild(detailElement);
		shadow.appendChild(feedbackElement);
		shadow.appendChild(choicesElement);
		shadow.appendChild(hintElement);
		shadow.appendChild(footerElement);
		footerElement.appendChild(hintButton);
		footerElement.appendChild(clearButton);
		footerElement.appendChild(submitButton);
		
		let observer = new MutationObserver((records, observer) => this.observed(records, observer));
		let observationConfig = {attributeFilter: ["module-id", "question-id", "user-id", "token"], attributes: true};
		observer.observe(this, observationConfig);
	}

	connectedCallback() {
		this.update();
	}
	
	update() {
		let moduleID = this.getAttribute("module-id");
		let questionID = this.getAttribute("question-id");
		this._userID = this.getAttribute("user-id");
		this._oauthToken = this.getAttribute("token");
		let infoPromise = _.getJSON(`https://nxbook.appspot.com/nxbook/api/v1.0/questions/${moduleID}/${questionID}`);
//		let infoPromise = _.getJSON("all_questions");
		
		infoPromise.then((data) => {
			console.log("Questions:", data);
			
			if (data[questionID]) {
				this.setQuestion(data[questionID]);
			}
		});
	}
	
	setQuestion(question) {
		this._question = question;
		this._lastHint = Infinity;
		
		this.reset();
		
		// Display the question
		this._questionElement.innerHTML = question.question;
		// Display the instruction
		if (question.instruction) {
			this._detailElement.innerHTML = question.instruction;
		} else {
			if (question.type == "radio") {
				this._detailElement.innerText = "Choose the best answer";
			} else if (question.type == "checkbox") {
				this._detailElement.innerText = "Select all that apply";
			}
		}
		// Show/hide the hint elements
		this._hintElement.style.display = "none";
		if (question.hints && question.hints.length > 0) {
			this._hintElement.setAttribute("current", 1);
			this._hintElement.setAttribute("max", question.hints.length);
			this._hintButtonElement.style.display = "";
		} else {
			this._hintButtonElement.style.display = "none";
		}
		// Register the answers
		this._choicesElement.type = question.type;
		this._choicesElement.choices = question.answers;
	}
	
	observed(records, observer) {
		this.update();
	}
	
	showNextHint() {
		this._lastHint++;
		if (this._question && this._lastHint >= this._question.hints.length) {
			this._lastHint = 0;
		}

		this._hintElement.style.display = "";
		this._hintElement.setAttribute("current", this._lastHint + 1);
		this._hintElement.setAttribute("text", this._question.hints[this._lastHint]);
	}
	
	resetHints() {
		this._lastHint = Infinity;
		this._hintElement.style.display = "none";
	}
	
	reset() {
		this.resetHints();
		this._feedbackElement.style.display = "none";
		this._choicesElement.reset();
	}
}

customElements.define("nxbook-question", Question);
export default Question;
