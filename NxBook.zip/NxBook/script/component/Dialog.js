class Dialog extends HTMLElement {
	constructor() {
		// Always call super first in constructor
		super();
		
		// Create a shadow root
		let shadow = this.attachShadow({mode: "open"});

		/*
		<div class="modal overlay">
			<div class="modal dialog">
				<div class="content">
					<div class="title">Hint (1/5)</div>
					<div class="body">This app doesn't have permission to use the location service on your device! You may need to go to your settings to turn on the location service or enable permission.</div>
				</div>
				<div class="button content">
					<div class="button" data-label="Cancel"></div>
					<div class="button" data-label="OK"></div>
				</div>
			</div>
		</div>
		*/
		
		// Create elements
		let dialog = document.createElement("div");
		dialog.className = "dialog";
		let content = document.createElement("div");
		content.className = "content";
		let title = document.createElement("div");
		title.className = "title";
		let body = document.createElement("div");
		body.className = "body";
		let buttonContent = document.createElement("div");
		buttonContent.className = "button content";

		let style = document.createElement("style");
		style.textContent = `
:host {
	display: block;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	transition: opacity .2s;
	cursor: default;
}

.dialog {
	position: fixed;
	top: 50%;
	left: 50%;
	max-width: calc(100vw - 80px);
	max-height: calc(100vh - 48px);
	padding-top: 24px;
	border: 1px solid #DADCE0;
	border-radius: 8px;
	background: #FFF;
	font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
	overflow: auto;
	box-shadow: 0 0 0 100vmax rgba(0,0,0,.45), 0 2px 6px 0 rgba(60, 64, 67, .3);
	transform: translateY(-50%) translateX(-50%);
}
.dialog .content {
	padding: 0 24px;
}
.dialog .title {
	font-size: 20px;
	padding-bottom: 20px;
	font-weight: bold;
}
.dialog .body {
	padding-bottom: 28px;
	font-size: 16px;
	font-weight: 400;
	color: rgba(0, 0, 0, 0.65);
}
.dialog .button.content {
	padding: 8px 8px 8px 0px;
	text-align: right;
	/* Don't render whitespace (like newlines) between elements (not a problem when programmatically added) */
	font-size: 0;
}
.dialog .button.content .button {
	position: relative;
	display: inline-flex;
	height: 36px;
	min-width: 64px;
	padding: 0 8px;
	text-align: center;
	border-radius: 4px;
	text-transform: uppercase;
	vertical-align: top;
	font-weight: 500;
	font-size: 14px;
	color: #2196F3;
	cursor: pointer;
}
.dialog .button.content > .button:not(:first-child) {
	margin-left: 8px;
}
.dialog .button.content .button:hover {
	background: rgba(0, 0, 0, 0.15);
}
.dialog .button.content .button::after {
	content: attr(data-label);
	margin: auto auto;
}
`;

		// Attach the created elements to the shadow dom
		shadow.appendChild(style);
		shadow.appendChild(dialog);
		shadow.appendChild(content);
		shadow.appendChild(title);
		shadow.appendChild(body);
		shadow.appendChild(buttonContent);
		
		let observer = new MutationObserver((records, observer) => this.observed(records, observer));
		let observationConfig = {attributeFilter: ["title", "body"], attributes: true};
		observer.observe(this, observationConfig);
		
		this.update();
	}

	connectedCallback() {
		this.update();
	}
	
	update() {
		let title = this.getAttribute("title");
		let body = this.getAttribute("body");
		
		// Show section based on existence of attribute

		this._wrapperElement.innerText = text;
	}
	
	observed(records, observer) {
		for (let i = 0; i < records.length; i++) {
			let record = records[i];

			this.update();
		}
	}
}

customElements.define("nxbook-dialog", Dialog);
export default Dialog;
