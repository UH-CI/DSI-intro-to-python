#!/bin/bash
# Generates an OAuth token for NxBook

# Read data
check=`cat .nxbook.auth 2>/dev/null`
if [ "$check" ]; then
	readarray -t auth < .nxbook.auth 2>/dev/null
	apiKey="${auth[0]}"
	email="${auth[1]}"
else
	echo "WARNING: This tool will store the API key and email in PLAIN TEXT in \".nxbook.auth\"! However, the password will NOT be stored."
fi

if [ -z "$apiKey" ]; then
	echo -n "Enter the API key: "
	read apiKey
else
	echo -n "Enter the API key (ENTER to leave unchanged): "
	read newAuthKey
	if [ "$newAuthKey" ]; then
		apiKey="$newAuthKey"
	fi
fi
if [ -z "$email" ]; then
	echo -n "Enter the email: "
	read email
else
	echo -n "Enter the email ($email): "
	read newEmail
	if [ "$newEmail" ]; then
		email="$newEmail"
	fi
fi
# Save data
printf "$apiKey\n$email\n" > .nxbook.auth

while true; do
	echo -n "Enter the password: "
	read -s password
	echo
	while [ -z "$password" ]; do
		echo "You MUST enter a password."
		echo -n "Enter the password: "
		read -s password
		echo
	done

	token=`curl -sS "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=$apiKey" -H 'Content-Type: application/json' --data-binary "{\"email\":\"$email\",\"password\":\"$password\",\"returnSecureToken\":true}" | grep idToken | sed -r 's/ *"idToken": "([A-Za-z0-9_\.-]+)",.*/\1/'`

	if [ -z "$token" ]; then
		printf "\nAuthentication error.\n\n"
	else
		printf "\n---------OAUTH TOKEN---------\n"
		echo "$token"
		break
	fi
done

printf "\nPress ENTER to exit."
read
