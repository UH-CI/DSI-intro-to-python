from IPython.core.display import display
from IPython.core.display import HTML
import requests
import getpass
auth_token = ""
email = ""

def get_auth_token(this_email):
	global auth_token
	global email
	email = this_email
	passwd = getpass.getpass()
	auth_url = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyAZ3aUmQeqLsnlC8RnQli-GK6jgCKX6ukU'
	payload =  {"email": this_email, "password": passwd, "returnSecureToken": True}
	session = requests.Session()
	response = session.post(auth_url, data=payload, timeout=5, verify=True)
	auth_token = response.json()["idToken"]	
	return auth_token


def initialize_nxbook():
	display(HTML("""
	<script>
		(() => {
			let script = document.createElement("script");
			script.src = "nxbook/jupyter/initialize.js";
			document.head.appendChild(script);
		})();
	</script>
	"""))

def nxbookShowQuestion(module_id, question_id):
	global auth_token
	global email
#	print(auth_token, email)
	return HTML("<nxbook-question notebook module-id=\"{}\" question-id=\"{}\" user-id=\"{}\" token=\"{}\"></nxbook-question>".format(module_id, question_id, email, auth_token))