(() => {
	let font = document.createElement("link");
	font.href = "https://fonts.googleapis.com/css?family=Roboto:300,400,700|Roboto+Mono";
	font.rel = "stylesheet";
	let script = document.createElement("script");
	script.src = "nxbook/script/component/Question.js";
	script.type = "module";
	
	document.head.appendChild(font);
	document.head.appendChild(script);
})();