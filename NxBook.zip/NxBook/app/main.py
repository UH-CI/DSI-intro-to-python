# based on code obtained here
# https://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask



import firebase_admin
# from firebase_admin import firestore
from google.cloud import firestore
from flask import Flask, jsonify, abort, make_response
from flask import request, Response

# Rendering
from flask import render_template


from functools import wraps

import google.auth.transport.requests
import google.oauth2.id_token

import flask_cors

HTTP_REQUEST = google.auth.transport.requests.Request()


app = Flask(__name__)
flask_cors.CORS(app)


firebase_admin.initialize_app()

db = firestore.Client()

"""
Functions for handling authentication
"""

def check_auth(headers):
    print("Checking auth")
    id_token = headers.split(' ').pop()
    try:
        claims = google.oauth2.id_token.verify_firebase_token(
        id_token, HTTP_REQUEST)
    except:
        return False
    if claims:
        return True
    else:
        return False

def authenticate_error():
    """Sends a 401 response that enables basic auth"""
    return Response(
    'Could not verify your credentials.\n', 401 ,
    {'WWW-Authenticate': '"Login Required"'})


def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization")
        print("\n\n%s\n\n" % auth)
        if not auth or not check_auth(auth):
            return authenticate_error()
        return f(*args, **kwargs)
    return decorated


@app.route('/')
def hello():
    return "Hello World"


"""
Functions handling modules
"""
@app.route('/nxbook/api/v1.0/modules', methods=['GET'])
def get_modules():
    print("In modules")
    # The following does not work in prod (on the google cloud )
    ## modules = [x.id for x in  db.document('questions/module').collections()]
    modules = [x.id for x in  db.collection('modules').get()]
    return jsonify({"modules": modules })


"""
Functions handling questions
"""

# @app.route('/nxbook/api/v1.0/questions', methods=['GET'])
# def get_questions():
#     print("In get_questions")
#     questions = {x.id:x.to_dict() for x in  db.collection('questions').get()}
    #     return jsonify(questions)


@app.route('/nxbook/api/v1.0/questions/<string:module>', methods=['GET'])
def get_questions(module):
    print("In get_questions")
    questions = {x.id:x.to_dict() for x in  db.collection('questions/module/{}'.format(module)).get()}
    return jsonify(questions)



# @app.route('/nxbook/api/v1.0/questions/<string:q_id>', methods=['GET'])
# def get_question(q_id):
#     # TODO make sure the q_id is valid or abort(404)
#     try: 
#         question = db.document("questions/%s" % q_id).get()
#     except:
#         abort(404)
#     return jsonify({question.id: question.to_dict()})


@app.route('/nxbook/api/v1.0/questions/<string:module>/<string:q_id>', methods=['GET'])
def get_question_module(module, q_id):
    # TODO make sure the q_id is valid or abort(404)
    try: 
        question = db.document("questions/module/{}/{}".format(module, q_id)).get()
    except:
        abort(404)
    return jsonify({question.id: question.to_dict()})



@app.route('/nxbook/api/v1.0/questions', methods=['POST'])
@requires_auth
def create_question():
    """
     A question json object has at least a quesiton,
     answers a type and correct answer(s).
    """
    # print("question {}".format(request.json))
    # TODO: validate the data is of the correct type
    # TODO: Make sure the no extra fields beyong those below are added
    # TODO: make sure the module does exist -- don't want to add erroneous module
    if not request.json or not \
            'module' in request.json and not \
            'question' in request.json and not \
            'answers' in request.json and not \
            'type' in request.json and not \
            'correct_answer' in request.json:
        abort(400)
    _, new_doc = db.collection('questions/module/{}'.format(request.json["module"])).add(request.json)
    return jsonify({new_doc.id :request.json}), 201



@app.route('/nxbook/api/v1.0/questions/remove/<string:module>/<string:q_id>', methods=['GET'])
@requires_auth
def remove_question(module, q_id):
    try: 
        db.collection('questions/module/{}'.format(module)).document("%s" % q_id).delete()
    except:
        abort(404)
    return jsonify({"deleted": "%s" % q_id})



"""
for handling submissions
quizzes, MCQs, etc.
"""

@app.route('/nxbook/api/v1.0/answers', methods=['POST'])
@requires_auth
def submit_answer():
    print("In SUBMIT ANSWER")
    print(request.json)
    if not request.json or not \
            'user_id' in request.json and not \
            'module' in request.json and not \
            'question_id' in request.json and not \
            'answers' in request.json and not \
            'correct' in request.json:
        abort(400)
    _, new_doc = db.collection('answers/module/{}'.format(request.json["module"])).add(request.json)
    # return jsonify({new_doc.id :request.json}), 201
    return jsonify({new_doc.id :request.json}), 201


# Returns all the answers of a question in a module
def answer_of_question(module, q_id):
    q = db.collection('answers/module/{}'.format(module )).where(u'question_id', u'==', q_id)
    answers = {x.id:x.to_dict() for x in  q.get()}    
    return answers

## @requires_auth
@app.route('/nxbook/api/v1.0/answers/<string:module>/<string:q_id>', methods=['GET'])
def get_answers(module, q_id):
    answers = answer_of_question(module, q_id)
    return jsonify(answers)

## @requires_auth
@app.route('/nxbook/api/v1.0/plot_answers/<string:module>/<string:q_id>',  methods=['GET'])
def plot_answers(module, q_id):
    if not module and not q_id:
        abort(400)
    
    data = answer_of_question(module, q_id)
    print(data)
    return render_template('display_answers.html', answers_data=data)



"""
for handling submissions
quizzes, MCQs, etc.
"""
@app.route('/nxbook/api/v1.0/modules/<string:module>', methods=['GET'])
def get_module_details(module):
    # TODO: Test to make sure we are getting the correct input
    module_info = db.collection('modules').document(module).get().to_dict()
    return jsonify(module_info)



"""
for handling errors
"""


# Return the error here 
@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

if __name__ == '__main__':
     app.run(debug=True)


