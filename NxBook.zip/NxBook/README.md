# NxBook

NxBook is Jupyter Notebook-based training platform. NxBook offers JavaScript web-components which can be used to instrument student learning and enhance two-way feedback. 